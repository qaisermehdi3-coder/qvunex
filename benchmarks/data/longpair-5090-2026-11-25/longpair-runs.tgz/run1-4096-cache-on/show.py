import json, sys
phase = sys.argv[1]
try:
    r = json.loads(sys.argv[2])
except Exception:
    print(f"  {phase}: script failed, see run.out"); sys.exit()
f = lambda x, u="": "unknown" if x is None else f"{x}{u}"
print(f"  {phase}: wall {r['wall']} s, aggregate {f(r['aggregate_tok_s'], ' output tok/s')}")
for k in ("A", "B"):
    x = r[k]
    print(f"    request {k} (prompt ~{x['prompt_words']} tokens): first token {f(x['first_token'], ' s')}, done {x['done']} s, "
          f"{x['tokens']} tokens streamed, longest gap {f(x['max_gap'], ' s')}")
    if x["rate_while_other_prefills"] is None and x["first_token"] is not None:
        w = "n/a (the other request's first token came first, or less than 1 s apart)"
    else:
        w = f"{f(x['rate_while_other_prefills'], ' tok/s')} (over {f(x['window_s'], ' s')})"
    print(f"      decode while the other is still being read: {w}; after: {f(x['rate_after'], ' tok/s')}")
    if x["error"]:
        print(f"      error: {x['error']}")
