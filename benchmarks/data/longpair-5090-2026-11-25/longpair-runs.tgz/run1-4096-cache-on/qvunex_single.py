#!/usr/bin/env python3
"""
qvunex_single.py — one file, no install, no dependencies.

Measures what each LLM call actually costs and what a finished task costs.

    WHY ONE FILE
    ------------
    Several people told me the same thing: they will not pip install a package
    from a stranger onto a machine that holds production credentials. Fair. So
    this is one file you can read in one sitting and paste into your own tree:
    about 2,200 lines, of which about 670 are the --selftest at the bottom.
    Standard library only. No network code anywhere — grep it. Nothing leaves
    the machine; it appends JSON lines to a file on your own disk.

    USE
    ---
        from qvunex_single import wrap, task, step, report

        client = wrap(anthropic.Anthropic())      # or OpenAI, or Google

        with task("outbound email"):
            with step("research"):
                ...
            with step("draft"):
                ...

        report()          # prints cost per finished task

    Async clients and streams are covered: an awaited call is timed until
    it returns, and a stream is recorded once, when you finish reading it,
    with the usage from its last chunk. One provider needs your help:
    OpenAI chat streams carry no usage unless you ask for it,

        client.chat.completions.create(..., stream=True,
                                       stream_options={"include_usage": True})

    Without that, those calls are marked usage missing, never counted as $0.

    Running your own model server (vLLM, or SGLang started with
    --enable-metrics)? Streams may come back with no usage, but the server
    still counts. Save its counters before and after, then:

        python3 qvunex_single.py --reconcile before.txt after.txt

    It also prints how fast the server read prompts and wrote answers, per
    request (vLLM only, for now) and for the whole server. Add --gpu-rate 0.83 (dollars per hour
    for the server) to see what each request cost at the load you actually ran.

    Server that scales to zero? Pass the whole billed time of the wake as
    --window, and add --boot (billing start to the first snapshot) and --tail
    (second snapshot to billing end). It splits the bill into boot, serving and
    the idle tail after the work.

    Want to know when a server sat paid and idle? Save its counters on a timer,
    e.g. `curl -s localhost:8000/metrics > snaps/$(date +%s).txt` every five
    minutes, then run `--idle snaps/*.txt --gpu-rate 2.69`. Every window
    between two snapshots is marked served, paid with nothing served, or
    unknown (a missing counter or a restart is never counted as idle).

    Try it with no API key and no network:

        python3 qvunex_single.py --demo

    Check every behaviour described here on your own machine:

        python3 qvunex_single.py --selftest

    RATE CARD
    ---------
    Costs need prices. Put a plain text file at ~/.qvunex/prices.txt:

        # model              input   output  cache_write  cache_read
        claude-sonnet-4-5    3.00    15.00   3.75         0.30
        gpt-5                1.25    10.00   1.5625       0.125
        gemini-3.6-flash     0.30    2.50    0.375        0.03

    Dollars per million tokens. A model with no entry is reported as unpriced
    and left out rather than estimated.

    Apache-2.0. https://github.com/qaisermehdi3-coder/qvunex
"""

from __future__ import annotations

import contextvars
import inspect
import json
import os
import statistics
import sys
import time
import uuid
from contextlib import contextmanager

SCHEMA_VERSION = "0.3"
DEFAULT_PATH = os.path.expanduser("~/.qvunex/events.jsonl")
DEFAULT_PRICES = os.path.expanduser("~/.qvunex/prices.txt")

# How a provider bills reasoning / thinking tokens. Recorded per call, never
# assumed globally, because providers disagree and none of them raise an error
# if you guess wrong.
INCLUDED = "included"   # already inside the output count; do not add again
EXTRA = "extra"         # billed on top of the output count; must be added

CACHE_WRITE_MULT_5M = 1.25   # a 5-minute cache write costs MORE than not caching
CACHE_WRITE_MULT_1H = 2.00
CACHE_READ_MULT = 0.10


# ---------------------------------------------------------------------------
# task / step attribution
# ---------------------------------------------------------------------------
# A ContextVar holding a tuple of (label, id) pairs, outermost first.
#
# WHAT INHERITS, tested rather than assumed:
#
#   asyncio tasks   YES. Each task copies the context at creation, so concurrent
#                   tasks keep separate labels and cannot leak into each other.
#   threads         NO on Python 3.10 to 3.13, which is what has been tested. A
#                   new thread starts with a fresh, empty context, so it sees no
#                   task and no step. Calls made in a worker thread are recorded
#                   with task=None and land in the "outside any task" line -
#                   honest, but not attributed. Newer Pythons may differ; run
#                   --selftest and it will tell you what yours does.
#   processes       NO.
#
# The thread case matters because many frameworks run tool calls and sub-agent
# calls on a ThreadPoolExecutor. If you own the thread, wrap the callable with
# contextvars.copy_context().run(fn) and the labels carry over. If a framework
# owns the pool, you cannot, so pass the id yourself:
#
#     tid = ...                      # captured in the parent
#     with task("my task", task_id=tid):
#         ...
#
# Exceptions are safe in all cases: every label is popped in a finally block, so
# a throw inside a step restores the stack rather than leaving a label stuck.

_stack: contextvars.ContextVar[tuple] = contextvars.ContextVar("qvunex_stack", default=())


@contextmanager
def task(name, task_id=None):
    """Name a unit of work. Cost per finished task is measured against this."""
    tid = task_id or uuid.uuid4().hex[:12]
    token = _stack.set(_stack.get() + ((name, tid),))
    try:
        yield tid
    finally:
        _stack.reset(token)


@contextmanager
def step(name):
    """Name a step inside a task, so calls can be attributed to it.

    Without this, calls made inside a task are recorded as UNATTRIBUTED rather
    than silently credited to the task as a whole. A total that looks complete
    and isn't is worse than a gap you can see.
    """
    token = _stack.set(_stack.get() + ((name, None),))
    try:
        yield
    finally:
        _stack.reset(token)


def _current():
    s = _stack.get()
    if not s:
        return None, None, None
    task_name, task_id = s[0]
    owner = s[-1][0] if len(s) > 1 else None
    return task_name, task_id, owner


# ---------------------------------------------------------------------------
# reading usage off a provider response
# ---------------------------------------------------------------------------
# Duck-typed on purpose. No SDK imports, so this file works whether or not you
# have any particular client library installed, and does not break when one of
# them changes its package layout.

def _get(obj, *names):
    for n in names:
        if isinstance(obj, dict) and n in obj:
            return obj[n]
        if hasattr(obj, n):
            return getattr(obj, n)
    return None


def extract_usage(response):
    """Return a dict of token counts, or None if this isn't a usage-bearing response."""
    u = _get(response, "usage", "usage_metadata")
    if u is None:
        return None

    out = {}

    # ---- OpenAI Responses API, and LangChain's usage_metadata ------------
    # Both say input_tokens, like Anthropic, but mean something different:
    # here input_tokens INCLUDES cached tokens, and reasoning is a subset of
    # output_tokens. Anthropic never sends total_tokens or a *_details
    # breakdown, so that is what tells them apart. Read as Anthropic, cached
    # tokens would be billed again at the full input price.
    if _get(u, "input_tokens") is not None and any(
            _get(u, k) is not None for k in ("total_tokens", "input_tokens_details",
                                             "input_token_details", "output_tokens_details",
                                             "output_token_details")):
        din = _get(u, "input_tokens_details", "input_token_details") or {}
        dout = _get(u, "output_tokens_details", "output_token_details") or {}
        out["cache_read"] = _get(din, "cached_tokens", "cache_read") or 0
        out["cache_write"] = _get(din, "cache_creation") or 0
        out["tokens_in"] = max(0, (_get(u, "input_tokens") or 0)
                               - out["cache_read"] - out["cache_write"])
        out["tokens_out"] = _get(u, "output_tokens") or 0
        out["tokens_reasoning"] = _get(dout, "reasoning_tokens", "reasoning") or 0
        out["reasoning_billed"] = INCLUDED
        out["tokens_total_reported"] = _get(u, "total_tokens")

    # ---- Anthropic shape -------------------------------------------------
    elif _get(u, "input_tokens") is not None:
        out["tokens_in"] = _get(u, "input_tokens") or 0
        out["tokens_out"] = _get(u, "output_tokens") or 0
        out["cache_write"] = _get(u, "cache_creation_input_tokens") or 0
        out["cache_read"] = _get(u, "cache_read_input_tokens") or 0
        # When BOTH cache fields are missing, something in between may have
        # dropped them: a gateway was reported doing exactly that
        # (gravitee-io/issues#11889), where direct calls carried the fields and
        # the same call through the gateway did not, so a call that cost about
        # $0.022 was recorded as $0.000012 (on Anthropic input_tokens EXCLUDES
        # the cache). Absent is not zero, so the call is marked. This is a
        # warning only; the recorded numbers are not changed. Not yet checked
        # against a live direct Anthropic call without caching.
        if (_get(u, "cache_creation_input_tokens") is None
                and _get(u, "cache_read_input_tokens") is None):
            out["cache_unreported"] = True
        # Anthropic folds thinking into output_tokens and never reports it apart.
        out["tokens_reasoning"] = 0
        out["reasoning_billed"] = INCLUDED
        # input_tokens EXCLUDES cached tokens on Anthropic.
        total = out["tokens_in"] + out["cache_write"] + out["cache_read"] + out["tokens_out"]
        out["tokens_total_reported"] = total

    # ---- Google shape ----------------------------------------------------
    elif _get(u, "prompt_token_count") is not None:
        out["tokens_in"] = _get(u, "prompt_token_count") or 0
        out["tokens_out"] = _get(u, "candidates_token_count") or 0
        out["cache_read"] = _get(u, "cached_content_token_count") or 0
        out["cache_write"] = 0
        thoughts = _get(u, "thoughts_token_count") or 0
        out["tokens_reasoning"] = thoughts
        # Measured on live gemini-3.6-flash calls, 22 September 2026, against
        # Google's own reported total:
        #     17 +   3 + 135 =   155
        #     19 +  81 + 776 =   876
        #     15 + 397 + 923 = 1,335
        # total = prompt + candidates + thoughts, exactly, every time.
        # Worth seeing the first one: the answer was 3 tokens and the thinking
        # was 135. Anything charting candidates_token_count as the output cost
        # reports 3 where 138 was billed.
        # So on Google, thinking is billed ON TOP of the output count.
        out["reasoning_billed"] = EXTRA if thoughts else INCLUDED
        out["tokens_total_reported"] = _get(u, "total_token_count")

    # ---- OpenAI shape ----------------------------------------------------
    elif _get(u, "prompt_tokens") is not None:
        out["tokens_in"] = _get(u, "prompt_tokens") or 0
        out["tokens_out"] = _get(u, "completion_tokens") or 0
        details = _get(u, "completion_tokens_details") or {}
        out["tokens_reasoning"] = _get(details, "reasoning_tokens") or 0
        # reasoning_tokens is a SUBSET of completion_tokens. Adding it again
        # inflates the bill.
        out["reasoning_billed"] = INCLUDED
        pd = _get(u, "prompt_tokens_details")
        if pd is None:
            # OpenAI itself always sends prompt_tokens_details. A self-hosted
            # server may not: vLLM 0.27.1 sends it only when started with
            # --enable-prompt-tokens-details (off by default). Live on a Colab
            # T4, 14 Oct 2026: three identical calls, the server counted 64 of
            # 105 prompt tokens as read from its prefix cache, and the client
            # was told nothing about it. Absent is not zero, so the call is
            # marked. Here prompt_tokens INCLUDES any cached tokens, so the
            # token count is right; only the cached / uncached split is unknown.
            out["cache_unreported"] = "split"
            pd = {}
        out["cache_read"] = _get(pd, "cached_tokens") or 0
        out["cache_write"] = 0
        # prompt_tokens is INCLUSIVE of cached tokens on OpenAI, so subtract
        # them back out to avoid counting the same tokens twice.
        out["tokens_in"] = max(0, out["tokens_in"] - out["cache_read"])
        out["tokens_total_reported"] = _get(u, "total_tokens")

    else:
        return None

    _reconcile(out)
    return out


def _reconcile(out):
    """Compare our parts against the provider's own total.

    That total is the one number we did not derive. Where the parts don't add
    up, record the gap. Never correct it: we do not know which side is wrong,
    and quietly adjusting a number to make a check pass is how a meter starts
    lying.
    """
    total = out.get("tokens_total_reported")
    if total is None:
        return
    accounted = (out.get("tokens_in", 0) + out.get("cache_read", 0)
                 + out.get("cache_write", 0) + out.get("tokens_out", 0))
    if out.get("reasoning_billed") == EXTRA:
        accounted += out.get("tokens_reasoning", 0)
    diff = total - accounted
    if diff:
        out["tokens_unaccounted"] = diff


# ---------------------------------------------------------------------------
# recording
# ---------------------------------------------------------------------------

class _Recorder:
    def __init__(self):
        self.path = os.environ.get("QVUNEX_PATH", DEFAULT_PATH)
        self.disabled = os.environ.get("QVUNEX_DISABLED") == "1"
        self._started = False

    def write(self, rec):
        if self.disabled:
            return
        try:
            d = os.path.dirname(self.path)
            if d:
                os.makedirs(d, exist_ok=True)
            if not self._started:
                self._started = True
                with open(self.path, "a") as f:
                    f.write(json.dumps({
                        "type": "session",
                        "schema": SCHEMA_VERSION,
                        "started": time.time(),
                    }) + "\n")
            with open(self.path, "a") as f:
                f.write(json.dumps(rec) + "\n")
        except Exception:
            # A measurement tool that can take down production is a tool nobody
            # installs twice. Never raise out of here.
            pass


_rec = _Recorder()


def configure(path=None, disabled=None):
    if path is not None:
        _rec.path = os.path.expanduser(path)
        _rec._started = False
    if disabled is not None:
        _rec.disabled = bool(disabled)


def _record(model, usage, seconds, status, attempt, ctx=None):
    # ctx is the (task, id, owner) captured when the call was MADE. A stream or
    # an awaited call can finish somewhere else, and must still be credited to
    # the step that started it.
    task_name, task_id, owner = ctx if ctx is not None else _current()
    rec = {
        "type": "call",
        "schema": SCHEMA_VERSION,
        "t": time.time(),
        "model": model,
        "task": task_name,
        "task_id": task_id,
        # If nothing named the step, the owner is unknown. It is recorded as
        # unattributed and shown on its own line, never folded into the parent.
        "owner": owner,
        "seconds": round(seconds, 6),
        "status": status,
        "attempt": attempt,
    }
    if usage:
        rec.update(usage)
    elif status == "ok":
        # The call succeeded and the provider returned no usage object. Its cost
        # is UNKNOWN, not zero. Left unmarked, this row is byte-identical to a
        # call that genuinely cost nothing - and a total that silently counts it
        # as free reads low, which is the direction nobody audits.
        rec["usage_missing"] = True
    _rec.write(rec)


# ---------------------------------------------------------------------------
# wrapping a client
# ---------------------------------------------------------------------------
# Wrapping the client matters more than decorating your own functions.
# Decorating only sees the calls you wrote; wrapping also catches the ones your
# framework makes on your behalf - which is where the spend hides when one
# request fans out into six sub-agent calls.

CALL_METHODS = (
    "create", "acreate", "stream",
    "generate_content", "generate_content_async", "generate_content_stream",
    "generate", "complete", "invoke",
)


class _Proxy:
    def __init__(self, inner, path=""):
        object.__setattr__(self, "_inner", inner)
        object.__setattr__(self, "_path", path)

    def __getattr__(self, name):
        attr = getattr(object.__getattribute__(self, "_inner"), name)
        path = object.__getattribute__(self, "_path")
        newpath = f"{path}.{name}" if path else name
        # Only terminal call methods are timed. Names like `messages`,
        # `chat` and `completions` are namespaces on their way to a call,
        # even when they are themselves callable - wrapping those would
        # record the lookup instead of the request.
        if callable(attr) and name in CALL_METHODS:
            return _timed(attr, newpath)
        if hasattr(attr, "__dict__") or hasattr(attr, "create"):
            return _Proxy(attr, newpath)
        return attr

    def __call__(self, *a, **k):
        return object.__getattribute__(self, "_inner")(*a, **k)


def _timed(fn, path):
    def inner(*a, **k):
        model = k.get("model") or "unknown"
        attempt = int(k.pop("_qvunex_attempt", 1))
        ctx = _current()
        t0 = time.perf_counter()
        try:
            resp = fn(*a, **k)
        except Exception:
            _record(model, None, time.perf_counter() - t0, "error", attempt, ctx)
            raise          # your exception propagates untouched
        if inspect.isawaitable(resp):
            # An async client returns a coroutine. Timing it here would time
            # the set-up, not the call, and its usage is not there yet.
            return _await_and_record(resp, model, attempt, ctx)
        return _finish(resp, model, t0, attempt, ctx)
    return inner


async def _await_and_record(aw, model, attempt, ctx):
    t0 = time.perf_counter()
    try:
        resp = await aw
    except Exception:
        _record(model, None, time.perf_counter() - t0, "error", attempt, ctx)
        raise
    return _finish(resp, model, t0, attempt, ctx)


def _is_stream(obj):
    if isinstance(obj, (str, bytes, dict, list, tuple)):
        return False
    return any(hasattr(obj, n) for n in ("__next__", "__anext__", "__aiter__"))


def _finish(resp, model, t0, attempt, ctx):
    usage = extract_usage(resp)
    if usage is None:
        if _is_stream(resp):
            # Usage arrives in the chunks, if at all, so record when it ends.
            return _MeteredStream(resp, model, t0, attempt, ctx)
        if hasattr(resp, "__enter__") or hasattr(resp, "__aenter__"):
            # A helper that returns a context manager around a stream,
            # e.g. Anthropic's client.messages.stream(...).
            return _MeteredManager(resp, model, t0, attempt, ctx)
    _record(model, usage, time.perf_counter() - t0, "ok", attempt, ctx)
    return resp


# ---------------------------------------------------------------------------
# streams
# ---------------------------------------------------------------------------
# A streamed call is recorded ONCE, when the stream ends, with the time it
# actually took and the usage seen in its chunks:
#   OpenAI   the final chunk carries usage, but only if you pass
#            stream_options={"include_usage": True}. Without it there is none.
#   Google   each chunk carries usage_metadata; the last one is the total.
#   Anthropic  message_start carries input usage, message_delta the output.
# If no usage ever arrives, the call is recorded as usage missing - cost
# unknown, not zero. A stream you stop reading early is recorded when it is
# closed or garbage collected, usually without usage, because the final chunk
# was never read.

_ANTHROPIC_USAGE_KEYS = ("input_tokens", "output_tokens",
                         "cache_creation_input_tokens", "cache_read_input_tokens")


class _MeteredStream:
    def __init__(self, inner, model, t0, attempt, ctx):
        self._inner, self._model, self._t0 = inner, model, t0
        self._attempt, self._ctx = attempt, ctx
        self._usage, self._acc, self._done = None, {}, False
        self._it = self._ait = None

    def _see(self, chunk):
        u = extract_usage(chunk)
        if u is None:
            # OpenAI Responses API: usage rides on the response.completed event
            inner = _get(chunk, "response")
            if inner is not None:
                u = extract_usage(inner)
        if u is not None:
            self._usage = u              # the last usage seen is the total
            return
        kind = _get(chunk, "type")
        if kind == "message_start":
            src = _get(_get(chunk, "message"), "usage")
        elif kind == "message_delta":
            src = _get(chunk, "usage")
        else:
            return
        for key in _ANTHROPIC_USAGE_KEYS:
            v = _get(src, key)
            if v is not None:
                self._acc[key] = v

    def _close(self, status="ok"):
        if self._done:
            return
        self._done = True
        usage = self._usage
        if usage is None and "input_tokens" in self._acc:
            usage = extract_usage({"usage": dict(self._acc)})
        if usage is None:
            # Anthropic's `for text in stream.text_stream` reads the events
            # without passing them through here. The SDK keeps its own running
            # message; use it only once stop_reason is set, because before the
            # final event its output count is a partial that would read low.
            try:
                snap = getattr(self._inner, "current_message_snapshot", None)
            except Exception:
                snap = None
            if snap is not None and _get(snap, "stop_reason") is not None:
                usage = extract_usage(snap)
        _record(self._model, usage, time.perf_counter() - self._t0,
                status, self._attempt, self._ctx)

    def __iter__(self):
        return self

    def __next__(self):
        if self._it is None:
            self._it = self._inner if hasattr(self._inner, "__next__") else iter(self._inner)
        try:
            chunk = next(self._it)
        except StopIteration:
            self._close()
            raise
        except Exception:
            self._close("error")
            raise
        self._see(chunk)
        return chunk

    def __aiter__(self):
        return self

    async def __anext__(self):
        if self._ait is None:
            self._ait = self._inner.__aiter__() if hasattr(self._inner, "__aiter__") else self._inner
        try:
            chunk = await self._ait.__anext__()
        except StopAsyncIteration:
            self._close()
            raise
        except Exception:
            self._close("error")
            raise
        self._see(chunk)
        return chunk

    def __enter__(self):
        if hasattr(self._inner, "__enter__"):
            self._inner.__enter__()
        return self

    def __exit__(self, *exc):
        try:
            if hasattr(self._inner, "__exit__"):
                return self._inner.__exit__(*exc)
        finally:
            self._close("error" if exc and exc[0] else "ok")

    async def __aenter__(self):
        if hasattr(self._inner, "__aenter__"):
            await self._inner.__aenter__()
        return self

    async def __aexit__(self, *exc):
        try:
            if hasattr(self._inner, "__aexit__"):
                return await self._inner.__aexit__(*exc)
        finally:
            self._close("error" if exc and exc[0] else "ok")

    def close(self):
        try:
            c = getattr(self._inner, "close", None)
            if c:
                c()
        finally:
            self._close()

    def __getattr__(self, name):
        attr = getattr(self._inner, name)
        if name.startswith("get_final") and callable(attr):
            def final(*a, **k):
                out = attr(*a, **k)
                u = extract_usage(out)
                if u is not None:
                    self._usage = u
                return out
            return final
        return attr

    def __del__(self):
        try:
            self._close()
        except Exception:
            pass


class _MeteredManager:
    """A context manager that yields a stream (Anthropic's messages.stream)."""
    def __init__(self, inner, model, t0, attempt, ctx):
        self._inner, self._args = inner, (model, t0, attempt, ctx)
        self._stream = None

    def __enter__(self):
        self._stream = _MeteredStream(self._inner.__enter__(), *self._args)
        return self._stream

    def __exit__(self, *exc):
        try:
            return self._inner.__exit__(*exc)
        finally:
            if self._stream is not None:
                self._stream._close("error" if exc and exc[0] else "ok")

    async def __aenter__(self):
        self._stream = _MeteredStream(await self._inner.__aenter__(), *self._args)
        return self._stream

    async def __aexit__(self, *exc):
        try:
            return await self._inner.__aexit__(*exc)
        finally:
            if self._stream is not None:
                self._stream._close("error" if exc and exc[0] else "ok")

    def __getattr__(self, name):
        return getattr(self._inner, name)

    def __del__(self):
        # Never entered: the call still happened, so it is still recorded,
        # as cost unknown rather than dropped.
        try:
            if self._stream is None:
                model, t0, attempt, ctx = self._args
                _record(model, None, time.perf_counter() - t0, "ok", attempt, ctx)
        except Exception:
            pass


def wrap(client):
    """Wrap a provider client so every call through it is recorded."""
    return _Proxy(client)


# ---------------------------------------------------------------------------
# prices
# ---------------------------------------------------------------------------

def load_prices(path=None):
    path = path or os.environ.get("QVUNEX_PRICES", DEFAULT_PRICES)
    cards = {}
    try:
        with open(path) as f:
            for line in f:
                line = line.split("#")[0].strip()
                if not line:
                    continue
                parts = line.split()
                if len(parts) < 3:
                    continue
                name = parts[0]
                nums = [float(x) for x in parts[1:]]
                card = {"input": nums[0], "output": nums[1]}
                card["cache_write"] = nums[2] if len(nums) > 2 else nums[0] * CACHE_WRITE_MULT_5M
                card["cache_read"] = nums[3] if len(nums) > 3 else nums[0] * CACHE_READ_MULT
                cards[name] = card
    except FileNotFoundError:
        pass
    return cards


def cost_of(rec, cards):
    """Dollars for one call, or None if the model has no rate card entry."""
    card = cards.get(rec.get("model"))
    if not card:
        return None
    billable = [("tokens_in", "input"), ("tokens_out", "output"),
                ("cache_write", "cache_write"), ("cache_read", "cache_read")]
    if rec.get("reasoning_billed") == EXTRA:
        billable.append(("tokens_reasoning", "output"))
    total = 0.0
    for field, price_key in billable:
        total += (rec.get(field, 0) or 0) * card.get(price_key, 0.0) / 1_000_000
    return total


# ---------------------------------------------------------------------------
# report
# ---------------------------------------------------------------------------

def _pct(vals, p):
    if not vals:
        return 0.0
    s = sorted(vals)
    k = (len(s) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(s) - 1)
    return s[lo] + (s[hi] - s[lo]) * (k - lo)


def report(path=None, prices=None, out=sys.stdout):
    path = path or _rec.path
    cards = load_prices(prices)

    calls = []
    try:
        with open(path) as f:
            for line in f:
                try:
                    r = json.loads(line)
                except Exception:
                    continue
                if r.get("type") == "call":
                    calls.append(r)
    except FileNotFoundError:
        print(f"no corpus at {path}", file=out)
        return

    if not calls:
        print(f"no calls recorded in {path}", file=out)
        return

    w = lambda s="": print(s, file=out)
    w("=" * 68)
    w("  QVUNEX REPORT")
    w("=" * 68)
    w(f"  corpus        {path}")
    w(f"  calls         {len(calls):,}")
    ts = [c["t"] for c in calls if isinstance(c.get("t"), (int, float))]
    if ts:
        fmt = lambda x: time.strftime("%Y-%m-%d %H:%M", time.gmtime(x))
        w(f"  period        {fmt(min(ts))} to {fmt(max(ts))} UTC")
    # Every dollar figure in this report goes through money(): a call whose
    # cost is unknown (no usage came back, or the model has no price) adds
    # nothing to the sum, so the figure says how many such calls it hides.
    # A sum printed without that note would read as complete when it is not.
    def unknown(c):
        return c.get("status") == "ok" and (c.get("usage_missing")
                                            or cost_of(c, cards) is None)

    def money(cs):
        cs = list(cs)
        known = sum(cost_of(c, cards) or 0 for c in cs)
        n = sum(1 for c in cs if unknown(c))
        return f"${known:.4f}" + (f" +{n} unknown" if n else "")

    w(f"  known cost    {money(calls)}")
    w(f"                check it against your provider's own usage page for the")
    w(f"                same account and the same period")

    unpriced = sorted({c.get("model") for c in calls if c.get("model") not in cards})
    unaccounted = sum(c.get("tokens_unaccounted", 0) or 0 for c in calls)

    # ---- cost per finished task -----------------------------------------
    tasks = {}
    untasked = []
    for c in calls:
        tid = c.get("task_id")
        if tid:
            tasks.setdefault((c.get("task"), tid), []).append(c)
        else:
            untasked.append(c)

    if tasks:
        # A task only counts as finished if its LAST call succeeded. A task that
        # crashed part way is not a finished task that happened to be cheap -
        # averaging it in at its partial cost drags the mean down silently.
        # Found on live Gemini data: one task hit a rate limit on its first
        # call, was averaged in at $0, and understated the mean by a third.
        #
        # A finished task is only averaged in if every successful call in it has
        # a known cost. One call with no usage, or on a model with no price,
        # makes the task's total a lower bound - and a workflow measured less
        # completely would otherwise look cheaper than one measured fully.
        # (Raised by OkFlan504 on r/LLMDevs; reproduced before it was fixed.)
        by_name = {}
        failed = {}
        coverage = {}
        for (name, _tid), cs in tasks.items():
            cost = sum(cost_of(c, cards) or 0 for c in cs)
            last = max(cs, key=lambda c: c.get("t", 0))
            if last.get("status") == "ok":
                ok = [c for c in cs if c.get("status") == "ok"]
                known = [c for c in ok if not c.get("usage_missing")
                         and cost_of(c, cards) is not None]
                cov = coverage.setdefault(name, [0, 0])
                cov[0] += len(known); cov[1] += len(ok)
                complete = len(known) == len(ok)
                by_name.setdefault(name, []).append((cost, len(cs), complete))
            else:
                failed.setdefault(name, []).append(cs)
        if by_name:
            w()
            w("-" * 68)
            w("  COST PER FINISHED TASK")
            w("-" * 68)
            w("  %-20s %4s %9s %9s %9s %6s %6s" % (
                "task", "n", "mean", "p50", "p95", "calls", "known"))
            partial = {}
            for name, rows in sorted(by_name.items(), key=lambda kv: -sum(r[0] for r in kv[1])):
                costs = [r[0] for r in rows if r[2]]
                partial_rows = [r for r in rows if not r[2]]
                if partial_rows:
                    partial[name] = partial_rows
                k, n = coverage[name]
                cols = ((f"${statistics.mean(costs):.4f}", f"${_pct(costs, 0.50):.4f}",
                          f"${_pct(costs, 0.95):.4f}") if costs else ("-", "-", "-"))
                w("  %-20s %4d %9s %9s %9s %6.1f %5d%%" % (
                    name[:20], len(costs), *cols,
                    statistics.mean([r[1] for r in rows]),
                    int(100 * k / n) if n else 0))
            w()
            w("  n counts only tasks where every call's cost is known. 'known' is")
            w("  the share of calls with a known cost. Compare workflows only where")
            w("  it is 100% - a lower number can make a workflow look cheaper just")
            w("  because less of it was measured. The mean and the p95 are different")
            w("  questions; an average hides the tasks that actually hurt.")
            for name, rows in sorted(partial.items()):
                w()
                w("  %d '%s' task(s) finished with calls of unknown cost — at least"
                  % (len(rows), name[:22]))
                w("  $%.4f known so far, counted apart, never averaged in"
                  % sum(r[0] for r in rows))
        if failed:
            w()
            for name, rows in sorted(failed.items()):
                w("  %d '%s' task(s) did not finish, %s spent before failing —"
                  % (len(rows), name[:22], money(c for cs in rows for c in cs)))
            w("  counted apart, never averaged into the finished ones")

    if untasked:
        w()
        w("  %d call(s) outside any task, %s — counted apart, never spread" %
          (len(untasked), money(untasked)))

    # ---- attribution ------------------------------------------------------
    inside = [c for c in calls if c.get("task_id")]
    unattributed = [c for c in inside if not c.get("owner")]
    if inside:
        w()
        w("-" * 68)
        w("  ATTRIBUTION")
        w("-" * 68)
        owners = {}
        for c in inside:
            owners.setdefault(c.get("owner") or "UNATTRIBUTED", []).append(c)
        for owner, cs in sorted(owners.items(), key=lambda kv: -sum(cost_of(c, cards) or 0 for c in kv[1])):
            w("  %-30s %6d calls   %s" % (owner[:30], len(cs), money(cs)))
        if unattributed:
            w()
            w("  UNATTRIBUTED means the call happened inside a task but nothing")
            w("  named the step. It is counted, never folded into the parent.")
            w("  If your framework does not say which sub-agent is calling, no")
            w("  amount of wrapping can invent it.")

    # ---- cache ------------------------------------------------------------
    cw = sum(c.get("cache_write", 0) or 0 for c in calls)
    cr = sum(c.get("cache_read", 0) or 0 for c in calls)
    if cw or cr:
        w()
        w("-" * 68)
        w("  CACHE")
        w("-" * 68)
        w(f"  written {cw:,} tokens    read back {cr:,} tokens")
        if cw and not cr:
            w()
            w("  Written and never read. A 5-minute write costs 1.25x input and a")
            w("  1-hour write costs 2x, while a read costs 0.1x — so this is a")
            w("  pure surcharge over not caching at all.")

    # ---- retries and fallbacks -------------------------------------------
    errors = [c for c in calls if c.get("status") == "error"]
    if errors:
        w()
        w("  errors                %d call(s) failed — included in the call counts"
          % len(errors))
        w("                        above, but they returned no usage, so they cost")
        w("                        nothing that can be measured here")

    retries = [c for c in calls if (c.get("attempt") or 1) > 1]
    if retries:
        w()
        w("  retries               %d call(s), %s — the same work paid for twice"
          % (len(retries), money(retries)))

    # ---- honesty ----------------------------------------------------------
    missing = [c for c in calls if c.get("usage_missing")]
    if missing:
        w()
        w("-" * 68)
        w(f"  USAGE MISSING  {len(missing)} call(s)")
        w("-" * 68)
        by_owner = {}
        for c in missing:
            by_owner.setdefault(c.get("owner") or ("UNATTRIBUTED" if c.get("task_id") else "outside any task"), 0)
            by_owner[c.get("owner") or ("UNATTRIBUTED" if c.get("task_id") else "outside any task")] += 1
        for owner, n in sorted(by_owner.items(), key=lambda kv: -kv[1]):
            w("  %-30s %6d calls   cost unknown" % (owner[:30], n))
        w()
        w("  These calls succeeded but the provider returned no usage object.")
        w("  Nothing was reported, which is not the same as free. Every dollar")
        w("  figure above that includes them says '+N unknown' and is only a")
        w("  lower bound. A low number is the one nobody audits, so it is")
        w("  marked rather than left silent.")

    no_cache = [c for c in calls if c.get("status") == "ok" and c.get("cache_unreported")]
    if no_cache:
        anth = [c for c in no_cache if c.get("cache_unreported") is True]
        split = [c for c in no_cache if c.get("cache_unreported") == "split"]
        w()
        w("-" * 68)
        w(f"  CACHE NOT REPORTED  {len(no_cache)} call(s)")
        w("-" * 68)
        if anth:
            w(f"  {len(anth)} came back in Anthropic's shape with no cache fields at all.")
            w("  A gateway or proxy in between can drop them. If these calls used")
            w("  prompt caching, their input is undercounted, because on Anthropic")
            w("  input_tokens leaves the cache out, and their cost above is only a")
            w("  lower bound. Check one call against the provider's own usage page.")
        if split:
            w(f"  {len(split)} came back in OpenAI's shape with no prompt_tokens_details.")
            w("  Their prompt token count includes any cached tokens, but how many")
            w("  were cached is unknown, so all of them are priced as fresh input:")
            w("  where cached input is cheaper, their cost above may be too high.")
            w("  A self-hosted vLLM server sends the split only when started with")
            w("  --enable-prompt-tokens-details; --reconcile shows its own count.")

    if unaccounted:
        w()
        w("-" * 68)
        w(f"  UNACCOUNTED  {unaccounted:,} tokens")
        w("-" * 68)
        w("  The provider's own reported total does not match the parts we")
        w("  recorded. Every cost above is short by at least this much. The gap")
        w("  is recorded, never corrected — we do not know which side is wrong.")

    if unpriced:
        w()
        w("  unpriced models (no rate card entry, left out rather than estimated):")
        for m in unpriced:
            w(f"    {m}")

    w()


# ---------------------------------------------------------------------------
# reconcile against a self-hosted server
# ---------------------------------------------------------------------------
# A self-hosted OpenAI-compatible server may send no usage on a stream unless
# the client asks for it (vLLM: stream_options.include_usage, or the server flag
# --enable-force-include-usage, which is off by default). Those calls are
# recorded as usage missing. The server still counted them. Compare the two:
#
#     curl -s localhost:8000/metrics > before.txt
#     ... run your traffic, with a fresh QVUNEX_PATH ...
#     curl -s localhost:8000/metrics > after.txt
#     python3 qvunex_single.py --reconcile before.txt after.txt
#
# This file still opens no network connection: you save the server's counters
# with curl, and this reads the saved files. It uses vLLM's per-finished-request
# counters, which match what a client's usage object would have said:
#   vllm:request_success_total             requests the server finished
#   vllm:request_prompt_tokens_sum         prompt tokens of those requests
#   vllm:request_generation_tokens_sum     output tokens of those requests
# Totals over the window become provable. Which call used how many tokens does
# not: counters are sums. That part stays unknown and is reported as unknown.

_SERVER_METRICS = (
    ("requests", "vllm:request_success_total"),
    ("prompt tokens", "vllm:request_prompt_tokens_sum"),
    ("output tokens", "vllm:request_generation_tokens_sum"),
)

# SGLang (started with --enable-metrics) keeps the same three counts under its
# own names, split by an is_streaming label that is summed here. Checked live
# on a Colab T4, SGLang 0.5.21, 4 October 2026: 8 chat requests moved them by
# exactly the client's 8 / 264 / 80; 2 streams sent without stream_options
# (so the client got no usage) were still counted, 2 / 66 / 64; and six
# /health plus six /v1/models calls left them unchanged, although SGLang's
# /health runs a one-token generation on the GPU, flagged not to be counted.
# SGLang's own warmup request at startup is already counted (1 / 6 / 8) by the
# time the server answers, so it falls in the first snapshot, not the window.
_ENGINES = (
    ("vLLM", _SERVER_METRICS),
    ("SGLang", (
        ("requests", "sglang:num_requests_total"),
        ("prompt tokens", "sglang:prompt_tokens_total"),
        ("output tokens", "sglang:generation_tokens_total"),
    )),
)


def _engine(*snaps):
    """(name, metrics) for the server these snapshots came from, or (None, None).

    Decided by which request counter is present. Snapshots holding both
    engines' counters are refused: one window must be one server.
    """
    found = [(n, ms) for n, ms in _ENGINES
             if any(k[0] == ms[0][1] for d in snaps for k in d)]
    return found[0] if len(found) == 1 else (None, "both" if found else None)


def _read_prometheus(path):
    """{(metric, model_name): value}, summed over engines and finish reasons."""
    import re
    line_re = re.compile(r'^([A-Za-z_:][A-Za-z0-9_:]*)(\{.*\})?\s+(\S+)')
    model_re = re.compile(r'model_name="((?:[^"\\]|\\.)*)"')
    vals = {}
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            m = line_re.match(line)
            if not m:
                continue
            name, labels, raw = m.groups()
            try:
                v = float(raw)
            except ValueError:
                continue
            mm = model_re.search(labels or "")
            key = (name, mm.group(1) if mm else None)
            vals[key] = vals.get(key, 0.0) + v
    return vals


def reconcile(before, after, path=None, model=None, prices=None,
              gpu_rate=None, window=None, boot=None, tail=None, out=sys.stdout):
    """Compare what the meter recorded with what a vLLM or SGLang server counted.

    With gpu_rate (dollars per hour for the whole server) it also prices the
    window the way self-hosting is actually billed: by the hour, busy or idle.

    For a server that scales to zero, pass the whole billed time of the wake as
    window, plus boot (billing start to the first snapshot) and tail (second
    snapshot to billing end). The report then splits the bill into boot, the
    serving window between the snapshots, and the tail after it.
    """
    w = lambda s="": print(s, file=out)
    b, a = _read_prometheus(before), _read_prometheus(after)
    engine, metrics = _engine(b, a)
    req_metric = metrics[0][1] if engine else None
    models = sorted({k[1] for k in a if k[0] == req_metric} - {None}) if engine else []
    if model:
        models = [m for m in models if m == model]

    path = path or _rec.path
    calls = []
    if os.path.exists(path):
        with open(path) as f:
            for line in f:
                try:
                    r = json.loads(line)
                except Exception:
                    continue
                if r.get("type") == "call" and (not model or r.get("model") == model):
                    calls.append(r)

    w("=" * 68)
    w("  QVUNEX RECONCILE  meter vs server")
    w("=" * 68)
    w(f"  events        {path}  ({len(calls)} calls)")
    if metrics == "both":
        w("  server        both vLLM and SGLang counters found")
        w()
        w("  Nothing to compare: one pair of snapshots must come from one server.")
        return None
    w(f"  server        {', '.join(models) + f'  ({engine})' if models else 'no vLLM or SGLang request counters found'}")
    if not models:
        w()
        w("  Nothing to compare: the snapshots hold no vllm:request_success_total")
        w("  and no sglang:num_requests_total. Check that they are /metrics output")
        w("  from the same server (SGLang needs --enable-metrics).")
        return None

    server = {}
    for label, metric in metrics:
        before_v = [b[(metric, m)] for m in models if (metric, m) in b]
        after_v = [a[(metric, m)] for m in models if (metric, m) in a]
        if len(after_v) != len(models) or len(before_v) != len(models):
            server[label] = None          # not in a snapshot: unknown, not zero
        elif sum(after_v) < sum(before_v):
            server[label] = "reset"       # counter went down: server restarted
        else:
            server[label] = sum(after_v) - sum(before_v)

    ok = [c for c in calls if c.get("status") == "ok"]
    missing = [c for c in ok if c.get("usage_missing")]
    known = [c for c in ok if not c.get("usage_missing")]
    meter = {
        "requests": len(ok),
        "prompt tokens": sum((c.get("tokens_in") or 0) + (c.get("cache_read") or 0)
                             + (c.get("cache_write") or 0) for c in known),
        "output tokens": sum(c.get("tokens_out") or 0 for c in known),
    }

    w()
    w("  %-16s %14s %14s %14s" % ("", "server", "meter", "gap"))
    gaps = {}
    for label, _ in metrics:
        s = server[label]
        if s is None:
            w("  %-16s %14s %14s %14s" % (label, "not in snapshot", f"{meter[label]:,}", "unknown"))
            continue
        if s == "reset":
            w("  %-16s %14s %14s %14s" % (label, "counter reset", f"{meter[label]:,}", "unknown"))
            continue
        g = int(round(s)) - meter[label]
        gaps[label] = g
        w("  %-16s %14s %14s %14s" % (label, f"{int(round(s)):,}", f"{meter[label]:,}", f"{g:+,}"))
    # How much of the prompt the server read from its prefix cache. vLLM keeps
    # this as vllm:prompt_tokens_cached; the client only hears it when the
    # server sends prompt_tokens_details (vLLM: --enable-prompt-tokens-details).
    cached = None
    if engine == "vLLM":
        cs = _delta(b, a, "vllm:prompt_tokens_cached_total", models)
        unrep = [c for c in known if c.get("cache_unreported")]
        cm = None if (unrep or missing) else sum(c.get("cache_read") or 0 for c in known)
        cached = {"server": cs, "meter": cm, "unreported": len(unrep)}
        if cs is not None:
            sv = "counter reset" if cs == "reset" else f"{int(round(cs)):,}"
            mv = "not reported" if unrep else ("unknown" if cm is None else f"{cm:,}")
            gv = (f"{int(round(cs)) - cm:+,}" if cm is not None and cs != "reset" else "unknown")
            w("  %-16s %14s %14s %14s" % ("  of which cached", sv, mv, gv))
    w()
    w(f"  {len(missing)} of {len(ok)} successful call(s) came back with no usage.")
    if cached and cached["unreported"] and cached["server"] not in (None, "reset"):
        w(f"  {cached['unreported']} call(s) had usage but no cache split (prompt_tokens_details).")
        w("  The server's own count above is the only place the cached part shows.")

    if any(server[l] in (None, "reset") for l, _ in metrics):
        w()
        w("  Some server counters are missing or went backwards (a restart between")
        w("  the snapshots). Those rows cannot be reconciled and are left unknown.")
    if gaps.get("requests", 0) != 0:
        w()
        w("  The server finished a different number of requests than the meter")
        w("  recorded calls. Other clients, calls outside the window, or requests")
        w("  still running when the second snapshot was taken all do this. The")
        w("  token gaps below are only meaningful when this row is +0.")
    elif missing and gaps.get("prompt tokens", 0) >= 0 and gaps.get("output tokens", 0) >= 0:
        w()
        w(f"  Requests match. The token gap is what the server counted for the")
        w(f"  {len(missing)} call(s) the client never got a count for. The total is now")
        w(f"  known; which of those calls used how much is still not.")
        pt, ot = gaps.get("prompt tokens"), gaps.get("output tokens")
        cards = load_prices(prices)
        card = cards.get(model or (models[0] if len(models) == 1 else None))
        if card and pt is not None and ot is not None:
            usd = (pt * card.get("input", 0) + ot * card.get("output", 0)) / 1e6
            w(f"  Priced at your rate card, the unrecorded part is ${usd:.4f}.")
    elif not missing and all(g == 0 for g in gaps.values()):
        w()
        w("  Meter and server agree exactly.")
    elif any(g < 0 for g in gaps.values()):
        w()
        w("  The meter recorded more than the server counted: the events file holds")
        w("  calls from outside this window or to another server. Use a fresh")
        w("  QVUNEX_PATH for each pair of snapshots.")
    w()
    # The window is the time between the two snapshots: given, or read from
    # the times the two files were written.
    src = "given"
    if window is None:
        try:
            window = os.path.getmtime(after) - os.path.getmtime(before)
            src = "from the snapshot files' times"
        except OSError:
            window = None
    speed = _server_speed(b, a, models, window, src, w, engine, metrics)
    gpu = None
    if gpu_rate is not None:
        # Self-hosted cost is the GPU's hourly price for the time it was held,
        # including idle time inside the window, because that is what is paid.
        w("-" * 68)
        w("  GPU COST  (self-hosted: paid by the hour, busy or idle)")
        w("-" * 68)
        if not window or window <= 0:
            w("  window        unknown - pass the seconds between snapshots with --window")
            gpu = {"window": None, "cost": None, "per_request": None, "per_m_output": None}
        else:
            cost = gpu_rate * window / 3600.0
            reqs, outs = server.get("requests"), server.get("output tokens")
            per_req = cost / reqs if isinstance(reqs, float) and reqs > 0 else None
            per_m = cost / outs * 1e6 if isinstance(outs, float) and outs > 0 else None
            # A counted zero is not a missing count: the window was paid for and
            # the server finished nothing in it. Say so, never "unknown".
            idle = isinstance(reqs, float) and reqs == 0
            w(f"  window        {window:,.1f} s  ({src})")
            w(f"  rate          ${gpu_rate:g}/hour for the whole server")
            w(f"  window cost   ${cost:.6f}")
            if per_req is not None:
                w(f"  per request   ${per_req:.6f}  ({int(reqs)} requests the server finished)")
            elif idle:
                w("  per request   none - the server finished 0 requests in this window")
            else:
                w("  per request   unknown - no request count")
            if per_m is not None:
                w(f"  per 1M output tokens  ${per_m:,.2f}")
            elif isinstance(outs, float) and outs == 0:
                w("  per 1M output tokens  none - 0 output tokens in this window")
            else:
                w("  per 1M output tokens  unknown - no output token count")
            if idle:
                w()
                w(f"  PAID, NOTHING SERVED  ${cost:.6f} for {window:,.1f} s with 0 requests")
                w("  finished. If this server should have been idle or scaled to zero,")
                w("  something kept it up: a health check, a model-list poll, a warm pool.")
            w()
            w("  Idle time inside the window is included, because it is paid for.")
            w("  This is the cost at the load you ran, on this machine - not a")
            w("  constant. Measure a few windows and report the spread. On a server")
            w("  that stays up, skip the first window after it starts: it can run")
            w("  far slower. On one that scales to zero, every wake is that first")
            w("  window, so measure it and pass the whole billed time as --window.")
            split = _wake_split(window, boot, tail, gpu_rate, w)
            gpu = {"window": window, "cost": cost, "per_request": per_req, "per_m_output": per_m,
                   "served_nothing": idle, "split": split}
        w()
    return {"server": server, "meter": meter, "gaps": gaps, "missing": len(missing), "cached": cached,
            "gpu": gpu, "speed": speed, "engine": engine}



def _wake_split(window, boot, tail, gpu_rate, w):
    """Where one billed wake went: boot, serving window, tail. Seconds and dollars.

    Only what was given is split. A part that was not given is unknown, never
    zero, and then the serving window is unknown too, because it is what is
    left over. Parts that add up to more than the window are refused.
    """
    if boot is None and tail is None:
        return None
    w()
    w("  WHERE THE BILLED TIME WENT")
    parts = {"boot": boot, "tail": tail}
    for k, v in parts.items():
        if v is not None and v < 0:
            w(f"  {k} is negative ({v:g} s) - not split.")
            return None
    known = sum(v for v in parts.values() if v is not None)
    if known > window:
        w(f"  boot and tail add up to {known:,.1f} s, more than the {window:,.1f} s")
        w("  window - they cannot all be in this bill. Not split.")
        return None
    serving = window - boot - tail if boot is not None and tail is not None else None
    split = {"boot": boot, "serving": serving, "tail": tail}
    names = {"boot": "boot (billing start to first snapshot)",
             "serving": "serving window (between snapshots)",
             "tail": "tail (second snapshot to billing end)"}
    for k in ("boot", "serving", "tail"):
        v = split[k]
        if v is None:
            why = "not given" if k != "serving" else "needs both boot and tail"
            w(f"    {names[k]:<40} unknown - {why}")
        else:
            w(f"    {names[k]:<40} {v:>8,.1f} s  {100 * v / window:5.1f}%"
              f"  ${gpu_rate * v / 3600.0:.6f}")
    if serving is not None and tail > serving:
        w("  The tail after the last snapshot cost more than the serving window.")
    if serving is not None and boot > serving:
        w("  The boot cost more than the serving window.")
    return split


def idle_series(paths, gpu_rate=None, out=sys.stdout):
    """Walk a series of saved /metrics snapshots and mark every window between
    two of them as served, paid-with-nothing-served, or unknown.

    Window times come from the file name when it is a Unix time (what
    `curl ... > snaps/$(date +%s).txt` writes), otherwise from the file's
    modification time. A missing counter is unknown and a counter that went
    down means the server restarted: neither is ever counted as idle.
    """
    import os as _os
    w = lambda s="": print(s, file=out)

    def stamp(path):
        stem = _os.path.splitext(_os.path.basename(path))[0]
        try:
            return float(stem), "file name"
        except ValueError:
            return _os.path.getmtime(path), "file time"

    missing = [p for p in paths if not _os.path.isfile(p)]
    for p in missing:
        w(f"  No such file: {p}")
    if missing:
        w("  If that is a pattern like snaps/*.txt, no snapshot was saved yet:")
        w("  check that the loop is running and that `ls snaps` shows files.")
    snaps = sorted((stamp(p) + (p,) for p in paths if p not in missing),
                   key=lambda t: t[0])
    if len(snaps) < 2:
        w("  Need at least two snapshots.")
        return None
    rows, served_s, idle_s, unknown_s = [], 0.0, 0.0, 0.0
    w("=" * 68)
    w("  QVUNEX IDLE  what each window between snapshots served")
    w("=" * 68)
    w(f"  {len(snaps)} snapshots, times from the {snaps[0][1]}")
    w()
    for (t0, _, p0), (t1, _, p1) in zip(snaps, snaps[1:]):
        b, a = _read_prometheus(p0), _read_prometheus(p1)
        engine, metrics = _engine(b, a)
        rq, ot = (metrics[0][1], metrics[2][1]) if engine else (None, None)
        models = sorted({k[1] for d in (a, b) for k in d if k[0] == rq} - {None}) if engine else []
        dt = t1 - t0
        reqs = _delta(b, a, rq, models) if models else None
        outs = _delta(b, a, ot, models) if models else None
        if reqs is None or dt <= 0:
            state, unknown_s = "unknown - counter missing or times out of order", unknown_s + max(dt, 0)
        elif reqs == "reset":
            state, unknown_s = "unknown - counter went down (server restarted?)", unknown_s + dt
        elif reqs == 0:
            state, idle_s = "PAID, NOTHING SERVED", idle_s + dt
        else:
            o = f", {int(outs):,} output tokens" if isinstance(outs, float) else ""
            state, served_s = f"served {int(reqs)} requests{o}", served_s + dt
        rows.append({"start": t0, "seconds": dt, "requests": reqs, "state": state})
        w(f"  {_os.path.basename(p0)} -> {_os.path.basename(p1)}  {dt:>9,.1f} s  {state}")
    total = served_s + idle_s + unknown_s
    w()
    w(f"  total          {total:>10,.1f} s")
    for name, v in (("served", served_s), ("nothing served", idle_s), ("unknown", unknown_s)):
        share = f"{100 * v / total:5.1f}%" if total > 0 else "  -  "
        cost = f"  ${gpu_rate * v / 3600.0:.6f}" if gpu_rate is not None else ""
        w(f"  {name:<14} {v:>10,.1f} s  {share}{cost}")
    if unknown_s:
        w("  Unknown windows are not counted as idle: the server's counters cannot")
        w("  say what happened in them.")
    w()
    return {"windows": rows, "served_s": served_s, "idle_s": idle_s, "unknown_s": unknown_s}

def _delta(b, a, metric, models):
    """after - before for one counter; None if absent, "reset" if it went down."""
    bv = [b[(metric, m)] for m in models if (metric, m) in b]
    av = [a[(metric, m)] for m in models if (metric, m) in a]
    if len(av) != len(models) or len(bv) != len(models):
        return None
    if sum(av) < sum(bv):
        return "reset"
    return sum(av) - sum(bv)


# How fast the server read prompts and wrote answers, from vLLM's own
# per-request histograms (checked in vLLM 0.27.1's source, v1/metrics):
#   prefill time = first token - scheduled   (prompt, plus the first token)
#   decode time  = last token - first token  (every output token after the first)
#   request_prefill_kv_computed_tokens = prompt tokens minus cached ones
# All are recorded for the same finished requests as request_success_total.
# Live on a Colab T4, vLLM 0.27.1, 25 Sept 2026: the decode token count
# (output minus one per request) matched vLLM's separate inter-token gap
# counter exactly (504 and 504), and the decode time matched its gap time.
# Same session, 8 requests one at a time vs 8 at once, three rounds each:
# per-request decode 169-170 vs 122-124 tokens/s, while the whole server
# went 151-154 vs 701-708 tokens/s. Priced from per-request speed, that load
# would look about 5.7x dearer than it was.
# These are each request's own time. When requests run at the same time their
# times overlap, so the per-request speed drops while the whole server does
# more. Cost comes from the whole server; the per-request speed is what one
# user waits for. Both are printed, never one passed off as the other.

def _server_speed(b, a, models, window, src, w, engine="vLLM", metrics=_SERVER_METRICS):
    d = lambda metric: _delta(b, a, metric, models)
    num = lambda v: isinstance(v, float)
    if engine != "vLLM":
        # Only vLLM's per-request timing histograms have been checked against
        # its source and a live run. For other servers the per-request speed is
        # left unknown; the whole-server figure needs only the output count.
        gen = d(metrics[2][1])
        whole = gen / window if num(gen) and window and window > 0 else None
        w("-" * 68)
        w(f"  SERVER SPEED  (from {engine}'s own counters)")
        w("-" * 68)
        w(f"  per request   unknown - not read for {engine} yet (only vLLM's are checked)")
        w("  whole server, over the window:")
        w("    output      " + (f"{whole:,.1f} tokens/s  ({int(gen):,} output tokens in"
                                f" {window:,.1f} s, {src}, idle included)" if whole is not None
                                else "unknown - no window or no output count"))
        w()
        return {"prefill": None, "decode": None, "whole_output": whole}
    reqs = d("vllm:request_success_total")
    new_prompt = d("vllm:request_prefill_kv_computed_tokens_sum")
    pre_s = d("vllm:request_prefill_time_seconds_sum")
    gen = d("vllm:request_generation_tokens_sum")
    dec_s = d("vllm:request_decode_time_seconds_sum")

    prefill = new_prompt / pre_s if num(new_prompt) and num(pre_s) and pre_s > 0 else None
    decode = None
    if num(gen) and num(reqs) and num(dec_s) and dec_s > 0:
        decode = (gen - reqs) / dec_s          # the first token of each is prefill's
    whole = gen / window if num(gen) and window and window > 0 else None

    w("-" * 68)
    w("  SERVER SPEED  (from vLLM's own counters)")
    w("-" * 68)
    w("  per request, each request's own time:")
    w("    prefill     " + (f"{prefill:,.0f} tokens/s  ({int(new_prompt):,} new prompt tokens"
                            f" in {pre_s:.3f} s; cached tokens left out)" if prefill is not None
                            else "unknown - prefill counters missing, reset or zero"))
    w("    decode      " + (f"{decode:,.1f} tokens/s  ({int(gen - reqs):,} tokens after each"
                            f" request's first, in {dec_s:.3f} s)" if decode is not None
                            else "unknown - decode counters missing, reset or zero"))
    w("  whole server, over the window:")
    w("    output      " + (f"{whole:,.1f} tokens/s  ({int(gen):,} output tokens in"
                            f" {window:,.1f} s, {src}, idle included)" if whole is not None
                            else "unknown - no window or no output count"))
    w()
    w("  With requests running at once, per-request speed falls and the whole")
    w("  server's rises. Price by the whole-server figure; it holds only at the")
    w("  load you ran.")
    w()
    return {"prefill": prefill, "decode": decode, "whole_output": whole}


# ---------------------------------------------------------------------------
# demo — no key, no network
# ---------------------------------------------------------------------------

class _FakeResp:
    def __init__(self, usage):
        self.usage = usage


class _FakeAnthropic:
    class messages:
        @staticmethod
        def create(model=None, **k):
            time.sleep(0.001)
            return _FakeResp({
                "input_tokens": 900, "output_tokens": 120,
                "cache_creation_input_tokens": 3400,
                "cache_read_input_tokens": 0,
            })


class _FakeGoogle:
    class models:
        @staticmethod
        def generate_content(model=None, **k):
            time.sleep(0.001)
            # thoughts are billed ON TOP of candidates on Google
            return _FakeResp(None) if False else type("R", (), {
                "usage_metadata": {
                    "prompt_token_count": 17,
                    "candidates_token_count": 144,
                    "thoughts_token_count": 589,
                    "total_token_count": 750,
                }})()


def _demo():
    import tempfile
    path = os.path.join(tempfile.mkdtemp(), "demo.jsonl")
    configure(path=path)

    prices = os.path.join(os.path.dirname(path), "prices.txt")
    with open(prices, "w") as f:
        f.write("claude-demo   3.00  15.00  3.75  0.30\n")
        f.write("gemini-demo   0.30   2.50  0.375 0.03\n")

    a = wrap(_FakeAnthropic())
    g = wrap(_FakeGoogle())

    for i in range(6):
        with task("outbound email"):
            with step("research"):
                g.models.generate_content(model="gemini-demo")
            with step("draft"):
                a.messages.create(model="claude-demo")
            # deliberately unnamed: this is what an un-instrumented sub-agent
            # call looks like in the report
            a.messages.create(model="claude-demo")

    with task("support triage"):
        a.messages.create(model="claude-demo", _qvunex_attempt=2)

    report(path=path, prices=prices)
    print(f"corpus written to {path}\n")


# ---------------------------------------------------------------------------
# selftest — every behaviour claimed in public, checked on your own machine
# ---------------------------------------------------------------------------
# These check the METER's own logic: attribution, arithmetic, what the report
# says. They use small stand-in provider objects shaped like the documented
# responses, so they cannot prove a live provider still behaves that way.
# For that, wrap a real client and read the report.

def _selftest(out=sys.stdout):
    import asyncio, ast, io, tempfile, threading
    w = lambda s="": print(s, file=out)
    results = []

    def check(name, ok, detail=""):
        results.append(bool(ok))
        w(("  PASS  " if ok else "  FAIL  ") + name + (f"  ({detail})" if detail else ""))

    def fresh():
        d = tempfile.mkdtemp()
        p = os.path.join(d, "events.jsonl")
        configure(path=p)
        return p

    def calls_in(p):
        # nothing recorded means no file at all - that is a failure to report,
        # not a reason for the selftest itself to crash
        if not os.path.exists(p):
            return []
        with open(p) as f:
            return [r for r in (json.loads(l) for l in f) if r.get("type") == "call"]

    def first(p):
        cs = calls_in(p)
        return cs[0] if cs else {}

    def text_of(p, prices):
        buf = io.StringIO()
        report(path=p, prices=prices, out=buf)
        return buf.getvalue()

    def fake(usage=None, raises=None, attr="usage"):
        class Ns:
            @staticmethod
            def create(model=None, **k):
                if raises:
                    raise raises
                return type("R", (), {attr: usage} if usage is not None else {})()
        return type("Client", (), {"messages": Ns})()

    def close(a, b):
        return abs(a - b) < 1e-12

    saved = (_rec.path, _rec._started)
    d = tempfile.mkdtemp()
    prices = os.path.join(d, "prices.txt")
    with open(prices, "w") as f:
        f.write("anth 3.00 15.00 3.75 0.30\n"
                "oai  1.00  4.00 1.25 0.10\n"
                "goog 1.00 10.00 1.25 0.10\n")
    cards = load_prices(prices)

    w("=" * 68)
    w("  QVUNEX SELFTEST")
    w("=" * 68)
    w(f"  python {sys.version.split()[0]}")
    w()

    try:
        # -- provider arithmetic ------------------------------------------
        w("  provider arithmetic")
        p = fresh()
        wrap(fake({"input_tokens": 100, "output_tokens": 50,
                   "cache_creation_input_tokens": 400,
                   "cache_read_input_tokens": 1000})).messages.create(model="anth")
        c = first(p)
        check("anthropic: input excludes cache, cache priced on its own",
              close(cost_of(c, cards), (100*3 + 50*15 + 400*3.75 + 1000*0.30) / 1e6))

        # the two shapes from gravitee-io/issues#11889: direct, then through
        # a gateway that dropped the cache fields
        p = fresh()
        wrap(fake({"input_tokens": 14, "output_tokens": 37,
                   "cache_creation_input_tokens": 0,
                   "cache_read_input_tokens": 4262})).messages.create(model="anth")
        wrap(fake({"input_tokens": 12, "output_tokens": 20})).messages.create(model="anth")
        direct, gw = calls_in(p)
        buf = io.StringIO()
        report(path=p, prices=prices, out=buf)
        check("anthropic: cache fields missing is flagged, never read as a cache of 0",
              not direct.get("cache_unreported") and gw.get("cache_unreported") is True
              and "CACHE NOT REPORTED  1 call(s)" in buf.getvalue())

        # The exact usage object vLLM 0.27.1 returned live on a Colab T4,
        # 14 Oct 2026, when the server had in fact read 32 of the 35 prompt
        # tokens from its prefix cache.
        p = fresh()
        live = {"completion_tokens": 16, "prompt_tokens": 35, "total_tokens": 51,
                "completion_tokens_details": None, "prompt_tokens_details": None}
        wrap(fake(live)).messages.create(model="oai")
        wrap(fake({"prompt_tokens": 35, "completion_tokens": 16, "total_tokens": 51,
                   "prompt_tokens_details": {"cached_tokens": 0}})).messages.create(model="oai")
        noted, told = calls_in(p)
        buf = io.StringIO()
        report(path=p, prices=prices, out=buf)
        check("openai shape: no prompt_tokens_details is a cache split unknown, not a cache of 0",
              noted.get("cache_unreported") == "split" and not told.get("cache_unreported")
              and noted.get("tokens_in") == 35 and noted.get("tokens_out") == 16
              and "CACHE NOT REPORTED  1 call(s)" in buf.getvalue()
              and "no prompt_tokens_details" in buf.getvalue())

        p = fresh()
        wrap(fake({"prompt_tokens": 1000, "completion_tokens": 200, "total_tokens": 1200,
                   "prompt_tokens_details": {"cached_tokens": 800},
                   "completion_tokens_details": {"reasoning_tokens": 150}})).messages.create(model="oai")
        c = first(p)
        check("openai: cached tokens not counted twice, reasoning not added again",
              close(cost_of(c, cards), (200*1 + 800*0.10 + 200*4) / 1e6))

        p = fresh()
        wrap(fake({"prompt_token_count": 10, "candidates_token_count": 5,
                   "thoughts_token_count": 20, "total_token_count": 35},
                  attr="usage_metadata")).messages.create(model="goog")
        c = first(p)
        check("google: thinking billed on top of output, and the parts match google's total",
              close(cost_of(c, cards), (10*1 + 5*10 + 20*10) / 1e6)
              and "tokens_unaccounted" not in c)

        p = fresh()
        wrap(fake({"input_tokens": 1000, "output_tokens": 300, "total_tokens": 1300,
                   "input_tokens_details": {"cached_tokens": 800},
                   "output_tokens_details": {"reasoning_tokens": 200}})).messages.create(model="oai")
        c = first(p)
        check("openai responses api: says input_tokens like anthropic, but cache is inside it",
              close(cost_of(c, cards), (200*1 + 800*0.10 + 300*4) / 1e6)
              and c.get("tokens_reasoning") == 200 and "tokens_unaccounted" not in c)

        p = fresh()
        wrap(fake({"input_tokens": 350, "output_tokens": 240, "total_tokens": 590,
                   "input_token_details": {"cache_read": 100, "cache_creation": 200},
                   "output_token_details": {"reasoning": 200}},
                  attr="usage_metadata")).messages.create(model="anth")
        c = first(p)
        check("langchain usage_metadata: cache read and write taken out of input, not billed twice",
              close(cost_of(c, cards), (50*3 + 240*15 + 200*3.75 + 100*0.30) / 1e6)
              and "tokens_unaccounted" not in c)

        p = fresh()
        wrap(fake({"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 175})
             ).messages.create(model="oai")
        c = first(p)
        check("provider total that does not match the parts is recorded as a gap",
              c.get("tokens_unaccounted") == 25, f"gap {c.get('tokens_unaccounted')}")

        # -- attribution ---------------------------------------------------
        w()
        w("  attribution")
        p = fresh()
        cl = wrap(fake({"input_tokens": 10, "output_tokens": 5}))
        with task("t"):
            with step("named"):
                cl.messages.create(model="anth")
            cl.messages.create(model="anth")
        cs = calls_in(p)
        check("a call no step names stays unowned, never folded into the parent",
              [x.get("owner") for x in cs] == ["named", None])
        check("the report prints it on an UNATTRIBUTED line",
              "UNATTRIBUTED" in text_of(p, prices))

        p = fresh()
        with task("t"):
            try:
                with step("boom"):
                    raise RuntimeError("x")
            except RuntimeError:
                pass
            # checked INSIDE the task: the task's own cleanup would otherwise
            # hide a step that failed to remove its label
            after_step = _current()
        check("an exception inside a step leaves no stale label behind",
              after_step[0] == "t" and after_step[2] is None and _current() == (None, None, None))

        p = fresh()
        async def worker(name, delay):
            with task(name):
                with step(name + "-step"):
                    await asyncio.sleep(delay)
                    cl.messages.create(model="anth")
        async def both():
            await asyncio.gather(worker("a", 0.02), worker("b", 0.01))
        # run in its own thread so this works even inside a notebook's event loop
        th = threading.Thread(target=lambda: asyncio.run(both()))
        th.start(); th.join()
        pairs = sorted((x.get("task"), x.get("owner")) for x in calls_in(p))
        check("concurrent asyncio tasks keep their labels separate",
              pairs == [("a", "a-step"), ("b", "b-step")])

        seen = {}
        with task("parent"):
            with step("parent-step"):
                t = threading.Thread(target=lambda: seen.__setitem__("plain", _current()[0]))
                t.start(); t.join()
                ctx = contextvars.copy_context()
                t = threading.Thread(target=lambda: seen.__setitem__("copied", ctx.run(lambda: _current()[0])))
                t.start(); t.join()
        inherits = seen.get("plain") == "parent"
        check("contextvars.copy_context() carries labels into a thread you own",
              seen.get("copied") == "parent")
        w("  INFO  a plain new thread %s the task label on this Python"
          % ("INHERITS" if inherits else "does NOT inherit"))

        # -- async and streaming -------------------------------------------
        w()
        w("  async and streaming")

        class _AsyncClient:
            class messages:
                @staticmethod
                async def create(model=None, **k):
                    await asyncio.sleep(0.03)
                    return type("R", (), {"usage": {"input_tokens": 100, "output_tokens": 20}})()
        p = fresh()
        async def _one():
            with task("t"):
                with step("s"):
                    return await wrap(_AsyncClient()).messages.create(model="anth")
        res = {}
        th = threading.Thread(target=lambda: res.__setitem__("r", asyncio.run(_one())))
        th.start(); th.join()
        c = first(p)
        check("an awaited call records its usage and its real duration",
              c.get("tokens_in") == 100 and not c.get("usage_missing")
              and c.get("seconds", 0) >= 0.02 and c.get("owner") == "s")

        def _chunk(text=None, usage=None):
            return type("Chunk", (), {"text": text, "usage": usage})()
        class _OAIStream:
            def __init__(self, chunks):
                self._c = iter(chunks)
            def __iter__(self):
                return self
            def __next__(self):
                time.sleep(0.01)
                return next(self._c)
        class _OAI:
            class chat:
                class completions:
                    @staticmethod
                    def create(model=None, **k):
                        return _OAIStream([_chunk("He"), _chunk("llo"),
                                           _chunk(None, {"prompt_tokens": 50, "completion_tokens": 2,
                                                         "total_tokens": 52})])
        p = fresh()
        with task("t"):
            with step("s"):
                s = wrap(_OAI()).chat.completions.create(model="oai", stream=True)
        got = "".join(ch.text for ch in s if ch.text)       # read OUTSIDE the step
        cs = calls_in(p)
        check("a stream is recorded once, with usage from its final chunk",
              got == "Hello" and len(cs) == 1 and cs[0].get("tokens_in") == 50
              and cs[0].get("tokens_out") == 2)
        check("a stream's time covers reading it, and it stays with the step that opened it",
              cs[0].get("seconds", 0) >= 0.025 and cs[0].get("owner") == "s")

        class _Gem:
            class models:
                @staticmethod
                def generate_content_stream(model=None, **k):
                    for n in (5, 12, 20):
                        yield type("C", (), {"usage_metadata": {
                            "prompt_token_count": 10, "candidates_token_count": n,
                            "thoughts_token_count": 30, "total_token_count": 40 + n}})()
        p = fresh()
        list(wrap(_Gem()).models.generate_content_stream(model="goog"))
        cs = calls_in(p)
        check("google's streaming method is recorded, with the last chunk's totals",
              len(cs) == 1 and cs[0].get("tokens_out") == 20 and cs[0].get("tokens_reasoning") == 30)

        class _GemAio:                    # client.aio.models.generate_content_stream
            class models:
                @staticmethod
                async def generate_content_stream(model=None, **k):
                    async def gen():
                        for n in (4, 9):
                            await asyncio.sleep(0.01)
                            yield type("C", (), {"usage_metadata": {
                                "prompt_token_count": 7, "candidates_token_count": n,
                                "total_token_count": 7 + n}})()
                    return gen()
        p = fresh()
        async def _aio():
            with task("t"):
                with step("s"):
                    st = await wrap(_GemAio()).models.generate_content_stream(model="goog")
            got = [ch async for ch in st]
            return got, len(calls_in(p))          # recorded at the end, not on cleanup
        th = threading.Thread(target=lambda: res.__setitem__("g", asyncio.run(_aio())))
        th.start(); th.join()
        cs = calls_in(p)
        check("an async stream (await, then async for) is recorded once, when it ends",
              res.get("g", ([], 0))[1] == 1 and len(res["g"][0]) == 2
              and len(cs) == 1 and cs[0].get("tokens_out") == 9
              and cs[0].get("seconds", 0) >= 0.015 and cs[0].get("owner") == "s")

        class _AnthEvents:
            class messages:
                @staticmethod
                def create(model=None, **k):
                    return iter([
                        {"type": "message_start", "message": {"usage": {
                            "input_tokens": 80, "output_tokens": 1,
                            "cache_creation_input_tokens": 0, "cache_read_input_tokens": 400}}},
                        {"type": "content_block_delta"},
                        {"type": "message_delta", "usage": {"output_tokens": 37}},
                    ])
        p = fresh()
        list(wrap(_AnthEvents()).messages.create(model="anth", stream=True))
        c = first(p)
        check("anthropic stream events are combined: input from the start, output from the end",
              c.get("tokens_in") == 80 and c.get("tokens_out") == 37 and c.get("cache_read") == 400)

        p = fresh()
        list(wrap(type("Client", (), {"messages": type("M", (), {
            "create": staticmethod(lambda model=None, **k: iter([_chunk("a"), _chunk("b")]))})})()
        ).messages.create(model="oai", stream=True))
        c = first(p)
        check("a stream that never reports usage is marked unknown, not free",
              c.get("usage_missing") is True)

        def _ev(**kw):
            return type("Ev", (), kw)()
        class _Responses:
            class responses:
                @staticmethod
                def create(model=None, **k):
                    return iter([
                        _ev(type="response.created", response=_ev(usage=None)),
                        _ev(type="response.output_text.delta", delta="hi"),
                        _ev(type="response.completed", response=_ev(usage={
                            "input_tokens": 60, "output_tokens": 9, "total_tokens": 69,
                            "input_tokens_details": {"cached_tokens": 40}})),
                    ])
        p = fresh()
        list(wrap(_Responses()).responses.create(model="oai", stream=True))
        c = first(p)
        check("openai responses stream: usage read off the response.completed event",
              c.get("tokens_in") == 20 and c.get("cache_read") == 40 and c.get("tokens_out") == 9)

        # Anthropic's client.messages.stream(...) returns a context manager.
        # Three ways people read it: iterate the events, call
        # get_final_message(), or iterate .text_stream, which bypasses us.
        def _anth_manager(stop_reason, snapshot=True):
            events = [
                _ev(type="message_start", message=_ev(usage={
                    "input_tokens": 70, "output_tokens": 1,
                    "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0})),
                _ev(type="content_block_delta"),
                _ev(type="message_delta", usage={"output_tokens": 25}),
            ]
            final = _ev(usage={"input_tokens": 70, "output_tokens": 25}, stop_reason="end_turn")
            snap = _ev(usage={"input_tokens": 70, "output_tokens": 25 if stop_reason else 1},
                       stop_reason=stop_reason)
            class MessageStream:
                def __init__(self):
                    self._it = iter(events)
                    if snapshot:
                        self.current_message_snapshot = snap
                    self.text_stream = iter(["some ", "text"])
                def __iter__(self):
                    return self
                def __next__(self):
                    return next(self._it)
                def get_final_message(self):
                    for _ in self._it:
                        pass
                    return final
            class Manager:
                def __enter__(self):
                    return MessageStream()
                def __exit__(self, *e):
                    return False
            class Client:
                class messages:
                    @staticmethod
                    def stream(model=None, **k):
                        return Manager()
            return wrap(Client())

        p = fresh()
        with task("t"):
            with step("s"):
                with _anth_manager("end_turn").messages.stream(model="anth") as s:
                    for _ in s:
                        pass
        cs = calls_in(p)
        ok_iter = len(cs) == 1 and cs[0].get("tokens_out") == 25 and cs[0].get("owner") == "s"
        p = fresh()
        with _anth_manager("end_turn", snapshot=False).messages.stream(model="anth") as s:
            s.get_final_message()
        c1 = first(p)
        p = fresh()
        with _anth_manager("end_turn").messages.stream(model="anth") as s:
            "".join(s.text_stream)
        c2 = first(p)
        check("anthropic messages.stream(): recorded once, whether you iterate, "
              "call get_final_message(), or read text_stream",
              ok_iter and c1.get("tokens_out") == 25 and c2.get("tokens_out") == 25)

        p = fresh()
        with _anth_manager(None).messages.stream(model="anth") as s:
            next(iter(s.text_stream))                     # stop reading early
        c = first(p)
        check("a stream left part read is marked unknown, not charged at its partial count",
              c.get("usage_missing") is True)

        class _Breaks:
            class messages:
                @staticmethod
                def create(model=None, **k):
                    def gen():
                        yield _chunk("a")
                        raise RuntimeError("connection dropped")
                    return gen()
        p = fresh()
        dropped = False
        try:
            list(wrap(_Breaks()).messages.create(model="oai", stream=True))
        except RuntimeError:
            dropped = True
        c = first(p)
        check("a stream that fails part way is recorded as an error, and you still get the error",
              dropped and c.get("status") == "error")

        # -- report honesty ------------------------------------------------
        w()
        w("  report honesty")
        p = fresh()
        ok = wrap(fake({"input_tokens": 1000, "output_tokens": 100}))
        bad = wrap(fake(raises=RuntimeError("rate limited")))
        with task("job"):
            ok.messages.create(model="anth")
        try:
            with task("job"):
                bad.messages.create(model="anth")
        except RuntimeError:
            pass
        txt = text_of(p, prices)
        one = (1000*3 + 100*15) / 1e6
        check("a crashed task is not averaged in as a cheap finished one",
              f"${one:.4f}" in txt and "did not finish" in txt)

        p = fresh()
        caught = False
        try:
            bad.messages.create(model="anth")
        except RuntimeError as e:
            caught = str(e) == "rate limited"
        c = first(p)
        check("your exception reaches you untouched, and is recorded as an error",
              caught and c.get("status") == "error" and not c.get("usage_missing"))

        p = fresh()
        with task("t"):
            with step("s"):
                wrap(fake(None)).messages.create(model="anth")
        c = first(p)
        txt = text_of(p, prices)
        check("a call with no usage object is marked unknown, not counted as free",
              c.get("usage_missing") is True and "USAGE MISSING" in txt and "lower bound" in txt)

        p = fresh()
        full = {"input_tokens": 1000, "output_tokens": 100}
        for _ in range(2):
            with task("measured"):
                wrap(fake(full)).messages.create(model="anth")
                wrap(fake(full)).messages.create(model="anth")
            with task("half measured"):
                wrap(fake(full)).messages.create(model="anth")
                wrap(fake(None)).messages.create(model="anth")
        txt = text_of(p, prices)
        row = [l for l in txt.splitlines() if l.strip().startswith("half measured")]
        check("a workflow with unknown-cost calls is not averaged in, so it cannot look cheaper",
              row and row[0].split()[2] == "0" and row[0].rstrip().endswith("50%")
              and "finished with calls of unknown cost" in txt)

        p = fresh()
        with task("t"):
            with step("draft"):
                wrap(fake({"input_tokens": 1000, "output_tokens": 100})).messages.create(model="anth")
                wrap(fake(None)).messages.create(model="anth")
        wrap(fake({"input_tokens": 1000, "output_tokens": 100})).messages.create(model="no-price")
        txt = text_of(p, prices)
        lines = txt.splitlines()
        draft = [l for l in lines if l.strip().startswith("draft")]
        outside = [l for l in lines if "outside any task" in l and "call(s)" in l]
        header = [l for l in lines if l.strip().startswith("known cost")]
        check("every dollar figure says how many calls of unknown cost it leaves out",
              draft and draft[0].rstrip().endswith("+1 unknown")
              and outside and "+1 unknown" in outside[0]
              and header and header[0].rstrip().endswith("+2 unknown"))

        # -- reconcile against a self-hosted server --------------------------
        w()
        w("  reconcile against a server")
        m = "local-model"
        def snap(req, pt, gt, extra=""):
            fn = os.path.join(tempfile.mkdtemp(), "m.txt")
            with open(fn, "w") as f:
                f.write(f'# TYPE vllm:request_success_total counter\n'
                        f'vllm:request_success_total{{engine="0",finished_reason="stop",model_name="{m}"}} {req}\n'
                        f'vllm:request_prompt_tokens_sum{{engine="0",model_name="{m}"}} {pt}\n'
                        + (f'vllm:request_generation_tokens_sum{{engine="0",model_name="{m}"}} {gt}\n'
                           if gt is not None else "") + extra)
            return fn
        p = fresh()
        wrap(fake({"prompt_tokens": 100, "completion_tokens": 40, "total_tokens": 140})).messages.create(model=m)
        wrap(fake(None)).messages.create(model=m)
        buf = io.StringIO()
        r = reconcile(snap(5, 1000, 300), snap(7, 1250, 400), path=p, prices=prices, out=buf)
        check("reconcile: the server's count fills the gap the missing call left, as a total",
              r and r["gaps"] == {"requests": 0, "prompt tokens": 150, "output tokens": 60}
              and r["missing"] == 1)
        cached_line = lambda n: (f'vllm:prompt_tokens_cached_total{{engine="0",model_name="{m}"}} {n}\n')
        buf = io.StringIO()
        rc = reconcile(snap(5, 1000, 300, cached_line(200)), snap(7, 1250, 400, cached_line(264)),
                       path=p, prices=prices, out=buf)
        check("reconcile: the server's cached prompt count is shown; the client's unknown split is not 0",
              rc and rc["cached"]["server"] == 64 and rc["cached"]["meter"] is None
              and "of which cached" in buf.getvalue())
        buf = io.StringIO()
        r1 = reconcile(snap(5, 1000, 300), snap(7, 900, None), path=p, prices=prices, out=buf)
        check("reconcile: a restarted server or a missing counter is unknown, not zero",
              r1 and r1["server"]["prompt tokens"] == "reset"
              and r1["server"]["output tokens"] is None
              and "prompt tokens" not in r1["gaps"] and "output tokens" not in r1["gaps"])

        buf = io.StringIO()
        r2 = reconcile(snap(5, 1000, 300), snap(7, 1250, 1300), path=p, prices=prices,
                       gpu_rate=3.6, window=100, out=buf)
        g = r2 and r2["gpu"]
        check("self-hosted cost: the hour rate over the window, split by the server's requests",
              g and close(g["cost"], 0.10) and close(g["per_request"], 0.05)
              and close(g["per_m_output"], 100.0))
        buf = io.StringIO()
        r3 = reconcile(snap(5, 1000, 300), snap(7, 1250, 400), path=p, prices=prices,
                       gpu_rate=3.6, window=0, out=buf)
        check("self-hosted cost: no window or no requests is unknown, never $0 per request",
              r3["gpu"]["per_request"] is None and "unknown" in buf.getvalue())
        buf = io.StringIO()
        r3b = reconcile(snap(5, 1000, 300), snap(5, 1000, 300), path=p, prices=prices,
                        gpu_rate=3.6, window=100, out=buf)
        g = r3b["gpu"]
        check("self-hosted cost: a paid window with 0 requests says nothing was served, not unknown",
              g["per_request"] is None and g["served_nothing"] is True and close(g["cost"], 0.10)
              and "PAID, NOTHING SERVED" in buf.getvalue()
              and "unknown - no request count" not in buf.getvalue())
        buf = io.StringIO()
        r3c = reconcile(snap(5, 1000, 300), snap(7, 1250, 400), path=p, prices=prices,
                        gpu_rate=3.6, window=100, boot=40, tail=50, out=buf)
        sp = r3c["gpu"]["split"]
        check("wake split: boot, serving and tail add up to the billed window",
              sp and close(sp["serving"], 10.0) and close(sp["boot"], 40.0)
              and close(sp["tail"], 50.0) and "$0.050000" in buf.getvalue()
              and "tail after the last snapshot cost more" in buf.getvalue())
        buf = io.StringIO()
        r3d = reconcile(snap(5, 1000, 300), snap(7, 1250, 400), path=p, prices=prices,
                        gpu_rate=3.6, window=100, boot=40, out=buf)
        sp = r3d["gpu"]["split"]
        check("wake split: a part not given is unknown, never 0",
              sp and sp["tail"] is None and sp["serving"] is None
              and buf.getvalue().count("unknown - ") >= 2)
        buf = io.StringIO()
        r3e = reconcile(snap(5, 1000, 300), snap(7, 1250, 400), path=p, prices=prices,
                        gpu_rate=3.6, window=100, boot=60, tail=50, out=buf)
        check("wake split: parts larger than the window are refused, not shown",
              r3e["gpu"]["split"] is None and "Not split" in buf.getvalue())
        sd = tempfile.mkdtemp()
        def snapfile(t, req, gt, drop=False):
            lab = f'{{engine="0",model_name="{m}"}}'
            body = "" if drop else f"vllm:request_success_total{lab} {req}\n"
            body += f"vllm:request_generation_tokens_sum{lab} {gt}\n"
            fp = os.path.join(sd, f"{t}.txt"); open(fp, "w").write(body); return fp
        files = [snapfile(1000, 0, 0), snapfile(1300, 0, 0), snapfile(1600, 5, 300),
                 snapfile(1900, 5, 300), snapfile(2200, 2, 50)]
        buf = io.StringIO()
        ri = idle_series(list(reversed(files)), gpu_rate=3.6, out=buf)
        check("idle series: zero-request windows are paid with nothing served, in time order",
              ri and close(ri["idle_s"], 600.0) and close(ri["served_s"], 300.0)
              and "$0.600000" in buf.getvalue() and "served 5 requests" in buf.getvalue())
        check("idle series: a restarted server's window is unknown, never idle",
              ri and close(ri["unknown_s"], 300.0) and "server restarted" in buf.getvalue())
        buf = io.StringIO()
        rj = idle_series([snapfile(3000, 0, 0), snapfile(3300, 0, 0, drop=True)], out=buf)
        check("idle series: a missing counter is unknown, not idle",
              rj and close(rj["idle_s"], 0.0) and close(rj["unknown_s"], 300.0))
        buf = io.StringIO()
        rn = idle_series([os.path.join(sd, "nothing-here", "*.txt")], out=buf)
        check("idle series: no snapshot files gives a plain message, not a crash",
              rn is None and "No such file" in buf.getvalue()
              and "Need at least two snapshots" in buf.getvalue())

        # The SGLang lines below are copied from the live run (Colab T4,
        # SGLang 0.5.21, 4 Oct 2026): B before the 8 chats, C after them,
        # D after 2 streams. Real output, not written to fit this code.
        lab = lambda st: (f'{{engine_type="unified",is_streaming="{st}",'
                          f'model_name="Qwen/Qwen2.5-0.5B-Instruct"}}')
        def sg(t, rows):
            fp = os.path.join(sd, f"{t}.txt")
            with open(fp, "w") as f:
                for st, (pt, gt, rq) in rows.items():
                    f.write(f"sglang:prompt_tokens_total{lab(st)} {pt}\n"
                            f"sglang:generation_tokens_total{lab(st)} {gt}\n"
                            f"sglang:num_requests_total{lab(st)} {rq}\n")
            return fp
        sB = sg(5000, {"false": ("6.0", "8.0", "1.0")})
        sC = sg(5030, {"false": ("270.0", "88.0", "9.0")})
        sD = sg(5060, {"false": ("270.0", "88.0", "9.0"), "true": ("66.0", "64.0", "2.0")})
        buf = io.StringIO()
        rs = reconcile(sB, sD, path=fresh(), prices=prices, gpu_rate=3.6, window=100, out=buf)
        check("sglang: its own counters are read, streamed and not streamed summed",
              rs and rs["engine"] == "SGLang"
              and rs["server"] == {"requests": 10.0, "prompt tokens": 330.0, "output tokens": 144.0}
              and close(rs["gpu"]["per_request"], 0.01) and "(SGLang)" in buf.getvalue()
              and "not read for SGLang yet" in buf.getvalue() and rs["speed"]["decode"] is None)
        buf = io.StringIO()
        rk = idle_series([sg(4970, {"false": ("6.0", "8.0", "1.0")}), sB, sC, sD],
                         gpu_rate=3.6, out=buf)
        check("sglang: idle series marks its windows too",
              rk and close(rk["idle_s"], 30.0) and close(rk["served_s"], 60.0)
              and "served 8 requests, 80 output tokens" in buf.getvalue())
        buf = io.StringIO()
        both = os.path.join(sd, "both.txt")
        open(both, "w").write(open(sC).read() + open(snapfile(9000, 3, 30)).read())
        rb = reconcile(both, both, path=fresh(), prices=prices, out=buf)
        check("snapshots holding both vLLM and SGLang counters are refused, not mixed",
              rb is None and "one server" in buf.getvalue())

        def hist(kv, pre, dec):
            lab = f'{{engine="0",model_name="{m}"}}'
            return (f"vllm:request_prefill_kv_computed_tokens_sum{lab} {kv}\n"
                    f"vllm:request_prefill_time_seconds_sum{lab} {pre}\n"
                    f"vllm:request_decode_time_seconds_sum{lab} {dec}\n")
        buf = io.StringIO()
        r4 = reconcile(snap(5, 1000, 300, hist(800, 0.4, 3.0)),
                       snap(7, 1250, 400, hist(1000, 0.5, 5.0)),
                       path=p, prices=prices, window=10, out=buf)
        s = r4 and r4["speed"]
        check("server speed: prefill counts only new prompt tokens, decode leaves out each first token",
              s and close(s["prefill"], 2000.0) and close(s["decode"], 49.0)
              and close(s["whole_output"], 10.0))
        buf = io.StringIO()
        r5 = reconcile(snap(5, 1000, 300), snap(7, 1250, 400), path=p, prices=prices,
                       window=10, out=buf)
        check("server speed: missing timing counters are unknown, never 0 tokens/s",
              r5["speed"]["prefill"] is None and r5["speed"]["decode"] is None
              and "unknown - prefill" in buf.getvalue())
        times = lambda pre, dec: "\n".join(hist(0, pre, dec).splitlines()[1:]) + "\n"
        buf = io.StringIO()
        r6 = reconcile(snap(5, 1000, 300, times(0.4, 3.0)), snap(7, 1250, 400, times(0.5, 5.0)),
                       path=p, prices=prices, window=10, out=buf)
        check("server speed: prefill time without its token counter is unknown, not 0 tokens/s",
              r6["speed"]["prefill"] is None and close(r6["speed"]["decode"], 49.0))

        # -- the claim anyone can grep -------------------------------------
        w()
        w("  what this file does not do")
        p = fresh()
        secret = "PRIVATE-selftest-7f3a91"
        class Leaky:
            api_key = "sk-" + secret
            class messages:
                @staticmethod
                def create(model=None, messages=None, system=None, **k):
                    r = type("R", (), {})()
                    r.usage = {"input_tokens": 12, "output_tokens": 4}
                    r.content = [{"type": "text", "text": "reply " + secret}]
                    r.id = "id-" + secret
                    return r
        with task("t"):
            with step("s"):
                wrap(Leaky()).messages.create(
                    model="anth", system="system " + secret,
                    messages=[{"role": "user", "content": "prompt " + secret}],
                    metadata={"user_id": "user-" + secret})
        written = open(p).read() if os.path.exists(p) else ""
        check("prompts, replies, API keys and ids are never written to the file",
              '"type": "call"' in written and secret not in written)
        net = {"socket", "urllib", "http", "requests", "httpx", "aiohttp",
               "ssl", "ftplib", "smtplib", "urllib3", "websocket", "websockets"}
        with open(os.path.abspath(__file__)) as f:
            tree = ast.parse(f.read())
        imported = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported |= {a.name.split(".")[0] for a in node.names}
            elif isinstance(node, ast.ImportFrom) and node.module:
                imported.add(node.module.split(".")[0])
        bad_imports = sorted(imported & net)
        check("no networking module is imported anywhere in this file",
              not bad_imports, ", ".join(bad_imports) if bad_imports else "")
    finally:
        _rec.path, _rec._started = saved

    passed = sum(results)
    w()
    w(f"  {passed} of {len(results)} passed")
    w()
    w("  These test the meter's own logic against stand-in responses shaped")
    w("  like each provider's documented usage object. They cannot tell you a")
    w("  live provider still reports that shape. To check that, wrap your real")
    w("  client, make one call, and read the report.")
    w()
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(_selftest())
    elif "--demo" in sys.argv:
        _demo()
    elif len(sys.argv) >= 4 and sys.argv[1] == "--idle":
        rest = sys.argv[2:]
        rate = None
        if "--gpu-rate" in rest:
            k = rest.index("--gpu-rate"); rate = float(rest[k + 1]); del rest[k:k + 2]
        idle_series(rest, gpu_rate=rate)
    elif len(sys.argv) >= 4 and sys.argv[1] == "--reconcile":
        arg = lambda flag: sys.argv[sys.argv.index(flag) + 1] if flag in sys.argv else None
        rate, win = arg("--gpu-rate"), arg("--window")
        boot, tail = arg("--boot"), arg("--tail")
        reconcile(sys.argv[2], sys.argv[3], model=arg("--model"),
                  gpu_rate=float(rate) if rate else None,
                  window=float(win) if win else None,
                  boot=float(boot) if boot else None,
                  tail=float(tail) if tail else None)
    elif len(sys.argv) > 1 and sys.argv[1] not in ("-h", "--help"):
        report(path=sys.argv[1])
    else:
        print(__doc__)
