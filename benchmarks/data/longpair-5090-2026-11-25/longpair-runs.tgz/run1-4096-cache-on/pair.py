import json, sys, time, threading, uuid
sys.path.insert(0, sys.argv[4])
import qvunex_single as q
from openai import OpenAI
port, model, maxtok = sys.argv[1], sys.argv[2], int(sys.argv[3])
la, lb, rawpath = int(sys.argv[5]), int(sys.argv[6]), sys.argv[7]
client = q.wrap(OpenAI(base_url=f"http://127.0.0.1:{port}/v1", api_key="x", timeout=3600))
recs = {}
lock = threading.Lock()
t0 = time.time()

def one(name, n):
    t = time.time()
    stamps, out, err = [], None, None
    try:
        stream = client.completions.create(model=model, prompt=f"{uuid.uuid4()} " + " ".join(["measure"] * n),
                                           max_tokens=maxtok, temperature=0, stream=True,
                                           stream_options={"include_usage": True},
                                           extra_body={"ignore_eos": True})
        for ch in stream:
            if ch.choices:
                stamps.append(time.time() - t0)
            if getattr(ch, "usage", None) is not None:
                out = ch.usage.completion_tokens
    except Exception as e:
        err = repr(e)[:200]
    with lock:
        recs[name] = {"start": t - t0, "end": time.time() - t0, "stamps": stamps, "out_tokens": out,
                      "prompt_words": n, "error": err}

ts = [threading.Thread(target=one, args=("A", la)), threading.Thread(target=one, args=("B", lb))]
[x.start() for x in ts]; [x.join() for x in ts]
json.dump(recs, open(rawpath, "w"))

def rate_between(r, a, b):
    n = sum(1 for s in r["stamps"] if a <= s < b)
    return (n / (b - a)) if b > a else None

res = {}
for name, r in recs.items():
    other = recs["B" if name == "A" else "A"]
    st = r["stamps"]
    first = st[0] if st else None
    gaps = [st[i + 1] - st[i] for i in range(len(st) - 1)]
    o_first = other["stamps"][0] if other["stamps"] else None
    # while the other request is still being read (its first token not yet out)
    # only windows of at least 1 s, so a few tokens cannot look like a rate
    w = rate_between(r, first, o_first) if (first is not None and o_first is not None and o_first - first >= 1.0) else None
    after_a = max(first, o_first) if (first is not None and o_first is not None) else first
    after = rate_between(r, after_a, st[-1]) if (st and after_a is not None and st[-1] > after_a) else None
    res[name] = {"prompt_words": r["prompt_words"], "first_token": None if first is None else round(first - r["start"], 3),
                 "done": round(r["end"] - r["start"], 2), "tokens": len(st), "out_tokens": r["out_tokens"],
                 "max_gap": round(max(gaps), 3) if gaps else None,
                 "rate_while_other_prefills": None if w is None else round(w, 2),
                 "window_s": None if w is None else round(o_first - first, 2),
                 "rate_after": None if after is None else round(after, 2), "error": r["error"]}
wall = max(r["end"] for r in recs.values()) - min(r["start"] for r in recs.values())
outs = [r["out_tokens"] for r in recs.values()]
res["wall"] = round(wall, 2)
res["aggregate_tok_s"] = None if any(o is None for o in outs) else round(sum(outs) / wall, 2)
print(json.dumps(res))
