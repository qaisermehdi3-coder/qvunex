#!/usr/bin/env bash
# save /metrics every 3 s until the stop file appears
i=0
while [ ! -f "$2/stop_poll" ]; do
  curl -s --noproxy "*" "http://127.0.0.1:$1/metrics" -o "$2/poll/m_$(printf %04d $i)_$(date +%s).txt"
  i=$((i+1)); sleep 3
done
