import sys
from vllm.utils.argparse_utils import FlexibleArgumentParser
from vllm.entrypoints.openai.cli_args import make_arg_parser
from vllm.engine.arg_utils import AsyncEngineArgs
from vllm.usage.usage_lib import UsageContext
a = make_arg_parser(FlexibleArgumentParser()).parse_args(sys.argv[1:])
if getattr(a, "model_tag", None):
    a.model = a.model_tag
c = AsyncEngineArgs.from_cli_args(a).create_engine_config(usage_context=UsageContext.OPENAI_API_SERVER)
s = c.scheduler_config
print(f"budget     max_num_batched_tokens {s.max_num_batched_tokens}, chunked prefill "
      f"{'on' if s.enable_chunked_prefill else 'off'}, max_num_seqs {s.max_num_seqs}, "
      f"async scheduling {getattr(s, 'async_scheduling', 'unknown')} "
      "(from vLLM's own EngineArgs for these flags, not from the server log)")
